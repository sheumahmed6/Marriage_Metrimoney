import java.lang.*;
public class Start
{
	public static void main(String[] args)
	{
		
		Welcome obj1 = new Welcome();
		//Login obj1 = new Login ();
		//Admin obj1 = new Admin();
         //Account obj1 = new Account ("13","14","15","16","17");
        //adminFrame.setVisible(true);
		//Registration obj1 = new Registration();
		//Basic obj1 = new Basic();
		//Amelia obj1 = new Amelia ();
		//Alice obj1 = new Alice ();
		//Tony obj1 = new Tony ();
		//Samir obj1 = new Samir ();
		//UsersFrame obj1 = new UsersFrame();
		//PaymentFrame obj1 = new PaymentFrame(basicWindow);
		obj1.setVisible(true);
	}
}